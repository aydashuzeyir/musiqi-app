package com.example.offlinemusic

import android.content.Context
import android.provider.MediaStore

/**
 * Cihazda olan musiqi fayllarini MediaStore vasitesile tapir.
 * Hec bir seransl/internet cagirisi yoxdur - hamisi lokaldir.
 */
object MusicScanner {

    fun scan(context: Context): List<Song> {
        val songs = mutableListOf<Song>()

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION
        )

        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

        context.contentResolver.query(
            collection,
            projection,
            selection,
            null,
            sortOrder
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol) ?: "Naməlum"
                val artist = cursor.getString(artistCol) ?: "Naməlum ifaçı"
                val duration = cursor.getLong(durationCol)
                val contentUri = android.content.ContentUris.withAppendedId(collection, id)

                songs.add(Song(id, title, artist, duration, contentUri.toString()))
            }
        }

        return songs
    }
}
