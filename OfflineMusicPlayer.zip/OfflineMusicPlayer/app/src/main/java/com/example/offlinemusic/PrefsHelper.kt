package com.example.offlinemusic

import android.content.Context

/**
 * Butun tetbiq tercihlerini (sevimliler, son dinlenenler, sriftler,
 * ekvalayzer preseti) cihazda lokal saxlayir. Internet lazim deyil.
 */
object PrefsHelper {
    private const val PREFS_NAME = "musiqim_prefs"
    private const val KEY_FAVORITES = "favorites"
    private const val KEY_RECENT = "recent"
    private const val KEY_FONT = "font_choice"
    private const val KEY_EQUALIZER = "equalizer_preset"
    private const val KEY_THEME = "theme_index"
    private const val KEY_GRID_SIZE = "grid_size"
    private const val KEY_PLAYLIST_NAMES = "playlist_names"

    private const val MAX_RECENT = 20

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getFavorites(context: Context): MutableSet<String> {
        return HashSet(prefs(context).getStringSet(KEY_FAVORITES, emptySet()) ?: emptySet())
    }

    fun isFavorite(context: Context, songId: Long): Boolean {
        return getFavorites(context).contains(songId.toString())
    }

    fun toggleFavorite(context: Context, songId: Long): Boolean {
        val favs = getFavorites(context)
        val key = songId.toString()
        val nowFavorite: Boolean
        if (favs.contains(key)) {
            favs.remove(key)
            nowFavorite = false
        } else {
            favs.add(key)
            nowFavorite = true
        }
        prefs(context).edit().putStringSet(KEY_FAVORITES, favs).apply()
        return nowFavorite
    }

    fun addRecent(context: Context, songId: Long) {
        val current = getRecentIds(context).toMutableList()
        current.remove(songId)
        current.add(0, songId)
        val trimmed = current.take(MAX_RECENT)
        val joined = trimmed.joinToString(",")
        prefs(context).edit().putString(KEY_RECENT, joined).apply()
    }

    fun getRecentIds(context: Context): List<Long> {
        val raw = prefs(context).getString(KEY_RECENT, "") ?: ""
        if (raw.isBlank()) return emptyList()
        return raw.split(",").mapNotNull { it.toLongOrNull() }
    }

    fun setFontChoice(context: Context, fontKey: String) {
        prefs(context).edit().putString(KEY_FONT, fontKey).apply()
    }

    fun getFontChoice(context: Context): String {
        return prefs(context).getString(KEY_FONT, "sans-serif") ?: "sans-serif"
    }

    fun setEqualizerPreset(context: Context, presetIndex: Int) {
        prefs(context).edit().putInt(KEY_EQUALIZER, presetIndex).apply()
    }

    fun getEqualizerPreset(context: Context): Int {
        return prefs(context).getInt(KEY_EQUALIZER, 0)
    }

    fun setThemeIndex(context: Context, index: Int) {
        prefs(context).edit().putInt(KEY_THEME, index).apply()
    }

    fun getThemeIndex(context: Context): Int {
        return prefs(context).getInt(KEY_THEME, 0)
    }

    fun setGridSize(context: Context, size: Int) {
        prefs(context).edit().putInt(KEY_GRID_SIZE, size).apply()
    }

    fun getGridSize(context: Context): Int {
        return prefs(context).getInt(KEY_GRID_SIZE, 1)
    }

    // ---- Pleylistler ----

    fun getPlaylistNames(context: Context): Set<String> {
        return prefs(context).getStringSet(KEY_PLAYLIST_NAMES, emptySet())?.toSet() ?: emptySet()
    }

    fun createPlaylist(context: Context, name: String) {
        val names = getPlaylistNames(context).toMutableSet()
        names.add(name)
        prefs(context).edit().putStringSet(KEY_PLAYLIST_NAMES, names).apply()
    }

    fun deletePlaylist(context: Context, name: String) {
        val names = getPlaylistNames(context).toMutableSet()
        names.remove(name)
        prefs(context).edit()
            .putStringSet(KEY_PLAYLIST_NAMES, names)
            .remove(playlistSongsKey(name))
            .apply()
    }

    fun addSongToPlaylist(context: Context, playlistName: String, songId: Long) {
        val ids = getPlaylistSongIds(context, playlistName).toMutableList()
        if (!ids.contains(songId)) {
            ids.add(songId)
            savePlaylistSongIds(context, playlistName, ids)
        }
    }

    fun getPlaylistSongIds(context: Context, playlistName: String): List<Long> {
        val raw = prefs(context).getString(playlistSongsKey(playlistName), "") ?: ""
        if (raw.isBlank()) return emptyList()
        return raw.split(",").mapNotNull { it.toLongOrNull() }
    }

    private fun savePlaylistSongIds(context: Context, playlistName: String, ids: List<Long>) {
        prefs(context).edit().putString(playlistSongsKey(playlistName), ids.joinToString(",")).apply()
    }

    private fun playlistSongsKey(name: String) = "playlist_songs_$name"
}
