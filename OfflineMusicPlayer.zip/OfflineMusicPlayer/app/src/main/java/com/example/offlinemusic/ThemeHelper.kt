package com.example.offlinemusic

import android.content.Context
import android.graphics.Color

/**
 * Muxtelif reng movzulari (Retro Music kimi) - istifadeci Ayarlardan
 * ve ya birbasa pleyerin icindeki palitra dugmesinden sece biler.
 */
object ThemeHelper {
    data class Theme(val name: String, val primary: Int, val dark: Int, val light: Int)

    val themes = listOf(
        // --- Movcud 7 movzu (toxunulmayib) ---
        Theme("Qara", Color.parseColor("#2B2B2B"), Color.parseColor("#000000"), Color.parseColor("#9E9E9E")),
        Theme("Ağ", Color.parseColor("#E0E0E0"), Color.parseColor("#FAFAFA"), Color.parseColor("#BDBDBD")),
        Theme("Göy", Color.parseColor("#03A9F4"), Color.parseColor("#01579B"), Color.parseColor("#81D4FA")),
        Theme("Yaşıl", Color.parseColor("#43A047"), Color.parseColor("#1B5E20"), Color.parseColor("#A5D6A7")),
        Theme("Qırmızı", Color.parseColor("#E53935"), Color.parseColor("#8B0000"), Color.parseColor("#FF8A80")),
        Theme("Sarı", Color.parseColor("#FDD835"), Color.parseColor("#F57F17"), Color.parseColor("#FFF59D")),
        Theme("Bənövşəyi", Color.parseColor("#8B5CF6"), Color.parseColor("#4A148C"), Color.parseColor("#C4A3FF")),

        // --- Tund renkler ---
        Theme("Tünd Göy", Color.parseColor("#1A237E"), Color.parseColor("#000051"), Color.parseColor("#534BAE")),
        Theme("Tünd Yaşıl", Color.parseColor("#1B5E20"), Color.parseColor("#003300"), Color.parseColor("#4C8C4A")),
        Theme("Tünd Qırmızı", Color.parseColor("#7B1FA2"), Color.parseColor("#4A0072"), Color.parseColor("#AE52D4")),
        Theme("Tünd Qəhvəyi", Color.parseColor("#4E342E"), Color.parseColor("#1B0000"), Color.parseColor("#7B5E57")),
        Theme("Tünd Bənövşəyi", Color.parseColor("#311B92"), Color.parseColor("#000063"), Color.parseColor("#6746C3")),

        // --- Aciq renkler ---
        Theme("Açıq Mavi", Color.parseColor("#4FC3F7"), Color.parseColor("#03A9F4"), Color.parseColor("#B3E5FC")),
        Theme("Açıq Yaşıl", Color.parseColor("#81C784"), Color.parseColor("#4CAF50"), Color.parseColor("#C8E6C9")),
        Theme("Açıq Çəhrayı", Color.parseColor("#F48FB1"), Color.parseColor("#EC407A"), Color.parseColor("#FCE4EC")),
        Theme("Krem", Color.parseColor("#FFE0B2"), Color.parseColor("#FFB74D"), Color.parseColor("#FFF8E1")),
        Theme("Açıq Bənövşəyi", Color.parseColor("#B39DDB"), Color.parseColor("#9575CD"), Color.parseColor("#EDE7F6")),

        // --- Neon renkler ---
        Theme("Neon Yaşıl", Color.parseColor("#39FF14"), Color.parseColor("#00CC00"), Color.parseColor("#B2FF59")),
        Theme("Neon Çəhrayı", Color.parseColor("#FF1493"), Color.parseColor("#C2005C"), Color.parseColor("#FF77C6")),
        Theme("Neon Sarı", Color.parseColor("#FFFF00"), Color.parseColor("#CCCC00"), Color.parseColor("#FFFF8D")),
        Theme("Neon Mavi", Color.parseColor("#00E5FF"), Color.parseColor("#00B8D4"), Color.parseColor("#84FFFF")),
        Theme("Neon Narıncı", Color.parseColor("#FF6D00"), Color.parseColor("#CC5500"), Color.parseColor("#FFAB40")),

        // --- Pastel renkler ---
        Theme("Pastel Bənövşəyi", Color.parseColor("#D1C4E9"), Color.parseColor("#B39DDB"), Color.parseColor("#EDE7F6")),
        Theme("Pastel Çəhrayı", Color.parseColor("#FFCDD2"), Color.parseColor("#EF9A9A"), Color.parseColor("#FFEBEE")),
        Theme("Pastel Mavi", Color.parseColor("#BBDEFB"), Color.parseColor("#90CAF9"), Color.parseColor("#E3F2FD")),
        Theme("Pastel Yaşıl", Color.parseColor("#C8E6C9"), Color.parseColor("#A5D6A7"), Color.parseColor("#E8F5E9")),
        Theme("Pastel Sarı", Color.parseColor("#FFF9C4"), Color.parseColor("#FFF59D"), Color.parseColor("#FFFDE7")),

        // --- Gradient-vari xususi tonlar ---
        Theme("Gündoğuşu", Color.parseColor("#FF7043"), Color.parseColor("#E64A19"), Color.parseColor("#FFAB91")),
        Theme("Okean", Color.parseColor("#00838F"), Color.parseColor("#005662"), Color.parseColor("#4DD0E1")),
        Theme("Aurora", Color.parseColor("#00BFA5"), Color.parseColor("#00695C"), Color.parseColor("#64FFDA")),
        Theme("Alov", Color.parseColor("#D84315"), Color.parseColor("#8B0000"), Color.parseColor("#FF8A65")),
        Theme("Buz", Color.parseColor("#B2EBF2"), Color.parseColor("#80DEEA"), Color.parseColor("#E0F7FA"))
    )

    fun getSelected(context: Context): Theme {
        val index = PrefsHelper.getThemeIndex(context)
        return themes.getOrElse(index) { themes[0] }
    }
}
