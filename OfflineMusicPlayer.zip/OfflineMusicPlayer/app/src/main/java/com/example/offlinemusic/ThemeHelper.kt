package com.example.offlinemusic

import android.content.Context
import android.graphics.Color

/**
 * Muxtelif reng movzulari (Retro Music kimi) - istifadeci Ayarlardan
 * ve ya birbasa pleyerin icindeki palitra dugmesinden sece biler.
 */
object ThemeHelper {
    data class Theme(val name: String, val primary: Int, val dark: Int, val light: Int)

    val themes = listOf(
        // --- Movcud 7 movzu (toxunulmayib) ---
        Theme("Qara", Color.parseColor("#2B2B2B"), Color.parseColor("#000000"), Color.parseColor("#9E9E9E")),
        Theme("Ağ", Color.parseColor("#E0E0E0"), Color.parseColor("#FAFAFA"), Color.parseColor("#BDBDBD")),
        Theme("Göy", Color.parseColor("#03A9F4"), Color.parseColor("#01579B"), Color.parseColor("#81D4FA")),
        Theme("Yaşıl", Color.parseColor("#43A047"), Color.parseColor("#1B5E20"), Color.parseColor("#A5D6A7")),
        Theme("Qırmızı", Color.parseColor("#E53935"), Color.parseColor("#8B0000"), Color.parseColor("#FF8A80")),
        Theme("Sarı", Color.parseColor("#FDD835"), Color.parseColor("#F57F17"), Color.parseColor("#FFF59D")),
        Theme("Bənövşəyi", Color.parseColor("#8B5CF6"), Color.parseColor("#4A148C"), Color.parseColor("#C4A3FF")),

        // --- Tund renkler ---
        Theme("Tünd Göy", Color.parseColor("#1A237E"), Color.parseColor("#000051"), Color.parseColor("#534BAE")),
        Theme("Tünd Yaşıl", Color.parseColor("#1B5E20"), Color.parseColor("#003300"), Color.parseColor("#4C8C4A")),
        Theme("Tünd Qırmızı", Color.parseColor("#7B1FA2"), Color.parseColor("#4A0072"), Color.parseColor("#AE52D4")),
        Theme("Tünd Qəhvəyi", Color.parseColor("#4E342E"), Color.parseColor("#1B0000"), Color.parseColor("#7B5E57")),
        Theme("Tünd Bənövşəyi", Color.parseColor("#311B92"), Color.parseColor("#000063"), Color.parseColor("#6746C3")),

        // --- Aciq renkler ---
        Theme("Açıq Mavi", Color.parseColor("#4FC3F7"), Color.parseColor("#03A9F4"), Color.parseColor("#B3E5FC")),
        Theme("Açıq Yaşıl", Color.parseColor("#81C784"), Color.parseColor("#4CAF50"), Color.parseColor("#C8E6C9")),
        Theme("Açıq Çəhrayı", Color.parseColor("#F48FB1"), Color.parseColor("#EC407A"), Color.parseColor("#FCE4EC")),
        Theme("Krem", Color.parseColor("#FFE0B2"), Color.parseColor("#FFB74D"), Color.parseColor("#FFF8E1")),
        Theme("Açıq Bənövşəyi", Color.parseColor("#B39DDB"), Color.parseColor("#9575CD"), Color.parseColor("#EDE7F6")),

        // --- Neon renkler ---
        Theme("Neon Yaşıl", Color.parseColor("#39FF14"), Color.parseColor("#00CC00"), Color.parseColor("#B2FF59")),
        Theme("Neon Çəhrayı", Color.parseColor("#FF1493"), Color.parseColor("#C2005C"), Color.parseColor("#FF77C6")),
        Theme("Neon Sarı", Color.parseColor("#FFFF00"), Color.parseColor("#CCCC00"), Color.parseColor("#FFFF8D")),
        Theme("Neon Mavi", Color.parseColor("#00E5FF"), Color.parseColor("#00B8D4"), Color.parseColor("#84FFFF")),
        Theme("Neon Narıncı", Color.parseColor("#FF6D00"), Color.parseColor("#CC5500"), Color.parseColor("#FFAB40")),

        // --- Pastel renkler ---
        Theme("Pastel Bənövşəyi", Color.parseColor("#D1C4E9"), Color.parseColor("#B39DDB"), Color.parseColor("#EDE7F6")),
        Theme("Pastel Çəhrayı", Color.parseColor("#FFCDD2"), Color.parseColor("#EF9A9A"), Color.parseColor("#FFEBEE")),
        Theme("Pastel Mavi", Color.parseColor("#BBDEFB"), Color.parseColor("#90CAF9"), Color.parseColor("#E3F2FD")),
        Theme("Pastel Yaşıl", Color.parseColor("#C8E6C9"), Color.parseColor("#A5D6A7"), Color.parseColor("#E8F5E9")),
        Theme("Pastel Sarı", Color.parseColor("#FFF9C4"), Color.parseColor("#FFF59D"), Color.parseColor("#FFFDE7")),

        // --- Gradient-vari xususi tonlar ---
        Theme("Gündoğuşu", Color.parseColor("#FF7043"), Color.parseColor("#E64A19"), Color.parseColor("#FFAB91")),
        Theme("Okean", Color.parseColor("#00838F"), Color.parseColor("#005662"), Color.parseColor("#4DD0E1")),
        Theme("Aurora", Color.parseColor("#00BFA5"), Color.parseColor("#00695C"), Color.parseColor("#64FFDA")),
        Theme("Alov", Color.parseColor("#D84315"), Color.parseColor("#8B0000"), Color.parseColor("#FF8A65")),
        Theme("Buz", Color.parseColor("#B2EBF2"), Color.parseColor("#80DEEA"), Color.parseColor("#E0F7FA")),

        // --- Movsumler ve ehval-ruhiyye ---
        Theme("Gecə", Color.parseColor("#0D1B2A"), Color.parseColor("#000000"), Color.parseColor("#415A77")),
        Theme("Sübh", Color.parseColor("#FFAB91"), Color.parseColor("#FF7043"), Color.parseColor("#FFE0B2")),
        Theme("Payız", Color.parseColor("#BF6900"), Color.parseColor("#7A3E00"), Color.parseColor("#FFB74D")),
        Theme("Qış", Color.parseColor("#90CAF9"), Color.parseColor("#42A5F5"), Color.parseColor("#E3F2FD")),
        Theme("Yaz", Color.parseColor("#AED581"), Color.parseColor("#7CB342"), Color.parseColor("#F1F8E9")),
        Theme("Yay", Color.parseColor("#FFD54F"), Color.parseColor("#FFA000"), Color.parseColor("#FFF8E1")),

        // --- Tebiet ---
        Theme("Meşə", Color.parseColor("#2E7D32"), Color.parseColor("#1B3B1F"), Color.parseColor("#66BB6A")),
        Theme("Səhra", Color.parseColor("#D7A86E"), Color.parseColor("#A0703E"), Color.parseColor("#F0DCC0")),
        Theme("Göl", Color.parseColor("#00897B"), Color.parseColor("#004D40"), Color.parseColor("#4DB6AC")),
        Theme("Dağ", Color.parseColor("#607D8B"), Color.parseColor("#37474F"), Color.parseColor("#B0BEC5")),

        // --- Metalik ---
        Theme("Qızılı", Color.parseColor("#D4AF37"), Color.parseColor("#8B6F1D"), Color.parseColor("#F1E2A8")),
        Theme("Gümüşü", Color.parseColor("#C0C0C0"), Color.parseColor("#8E8E8E"), Color.parseColor("#E8E8E8")),
        Theme("Bürünc", Color.parseColor("#CD7F32"), Color.parseColor("#8C5523"), Color.parseColor("#E3B98C")),

        // --- Daha coxlu neon/pastel ---
        Theme("Neon Bənövşəyi", Color.parseColor("#D500F9"), Color.parseColor("#AA00FF"), Color.parseColor("#EA80FC")),
        Theme("Neon Qırmızı", Color.parseColor("#FF1744"), Color.parseColor("#C4001D"), Color.parseColor("#FF8A80")),
        Theme("Pastel Narıncı", Color.parseColor("#FFE0B2"), Color.parseColor("#FFCC80"), Color.parseColor("#FFF3E0")),
        Theme("Pastel Türkuaz", Color.parseColor("#B2DFDB"), Color.parseColor("#80CBC4"), Color.parseColor("#E0F2F1")),

        // --- Elave canli tonlar ---
        Theme("Vivid Qırmızı", Color.parseColor("#F44336"), Color.parseColor("#B71C1C"), Color.parseColor("#FFCDD2")),
        Theme("Vivid Mavi", Color.parseColor("#2196F3"), Color.parseColor("#0D47A1"), Color.parseColor("#BBDEFB")),
        Theme("Vivid Yaşıl", Color.parseColor("#4CAF50"), Color.parseColor("#2E7D32"), Color.parseColor("#C8E6C9")),

        // --- Qiymetli daslar ---
        Theme("Zümrüd", Color.parseColor("#009B77"), Color.parseColor("#00695C"), Color.parseColor("#80CBC4")),
        Theme("Yaqut", Color.parseColor("#9B111E"), Color.parseColor("#5C0A12"), Color.parseColor("#E57373")),
        Theme("Sapfir", Color.parseColor("#0F52BA"), Color.parseColor("#08316E"), Color.parseColor("#64B5F6")),
        Theme("Ametist", Color.parseColor("#9966CC"), Color.parseColor("#5E2D91"), Color.parseColor("#CBA6E8")),
        Theme("İnci", Color.parseColor("#F0EAD6"), Color.parseColor("#D8CFC0"), Color.parseColor("#FFFDF7")),

        // --- Sema ve kosmos ---
        Theme("Göy Üzü", Color.parseColor("#5D9CEC"), Color.parseColor("#3B6FC4"), Color.parseColor("#AED2F5")),
        Theme("Kainat", Color.parseColor("#1A0033"), Color.parseColor("#000014"), Color.parseColor("#6C3AA8")),
        Theme("Ulduz", Color.parseColor("#3F51B5"), Color.parseColor("#1A237E"), Color.parseColor("#9FA8DA")),
        Theme("Süd Yolu", Color.parseColor("#4527A0"), Color.parseColor("#1A0057"), Color.parseColor("#B39DDB")),

        // --- Cixolad ve isiqlar ---
        Theme("Şokolad", Color.parseColor("#5D4037"), Color.parseColor("#3E2723"), Color.parseColor("#A1887F")),
        Theme("Vanil", Color.parseColor("#F3E5AB"), Color.parseColor("#E6D28A"), Color.parseColor("#FFFDE7")),
        Theme("Neon İşıq", Color.parseColor("#00FFAB"), Color.parseColor("#00CC88"), Color.parseColor("#B2FFEC")),
        Theme("Disko", Color.parseColor("#E040FB"), Color.parseColor("#AA00FF"), Color.parseColor("#F8BBD0")),

        // --- Elave mixed tonlar ---
        Theme("Mərcan", Color.parseColor("#FF7F50"), Color.parseColor("#CC5A32"), Color.parseColor("#FFB199")),
        Theme("Nanə", Color.parseColor("#98FF98"), Color.parseColor("#5FCB5F"), Color.parseColor("#E0FFE0")),
        Theme("Lavanda", Color.parseColor("#B57EDC"), Color.parseColor("#7D4FA0"), Color.parseColor("#E6D4F5")),
        Theme("Xardal", Color.parseColor("#C4A000"), Color.parseColor("#8C7200"), Color.parseColor("#E8D48A"))
    )

    fun getSelected(context: Context): Theme {
        val index = PrefsHelper.getThemeIndex(context)
        return themes.getOrElse(index) { themes[0] }
    }
}
