package com.example.offlinemusic

import android.content.Context
import android.graphics.Color

/**
 * Muxtelif reng movzulari (Retro Music kimi) - istifadeci Ayarlardan
 * ve ya birbasa pleyerin icindeki palitra dugmesinden sece biler.
 */
object ThemeHelper {
    data class Theme(val name: String, val primary: Int, val dark: Int, val light: Int)

    val themes = listOf(
        Theme("Qara", Color.parseColor("#2B2B2B"), Color.parseColor("#000000"), Color.parseColor("#9E9E9E")),
        Theme("Ağ", Color.parseColor("#E0E0E0"), Color.parseColor("#FAFAFA"), Color.parseColor("#BDBDBD")),
        Theme("Göy", Color.parseColor("#03A9F4"), Color.parseColor("#01579B"), Color.parseColor("#81D4FA")),
        Theme("Yaşıl", Color.parseColor("#43A047"), Color.parseColor("#1B5E20"), Color.parseColor("#A5D6A7")),
        Theme("Qırmızı", Color.parseColor("#E53935"), Color.parseColor("#8B0000"), Color.parseColor("#FF8A80")),
        Theme("Sarı", Color.parseColor("#FDD835"), Color.parseColor("#F57F17"), Color.parseColor("#FFF59D")),
        Theme("Bənövşəyi", Color.parseColor("#8B5CF6"), Color.parseColor("#4A148C"), Color.parseColor("#C4A3FF"))
    )

    fun getSelected(context: Context): Theme {
        val index = PrefsHelper.getThemeIndex(context)
        return themes.getOrElse(index) { themes[0] }
    }
}
