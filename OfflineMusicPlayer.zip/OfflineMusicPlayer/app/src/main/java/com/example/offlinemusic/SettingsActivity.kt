package com.example.offlinemusic

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.offlinemusic.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private var playbackService: PlaybackService? = null
    private var isBound = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            try {
                val binder = service as PlaybackService.LocalBinder
                playbackService = binder.getService()
                isBound = true
            } catch (e: Exception) {
                // servis birlesdirile bilmese, ayarlar yene de acila bilsin
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            isBound = false
            playbackService = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        try {
            Intent(this, PlaybackService::class.java).also { intent ->
                bindService(intent, connection, Context.BIND_AUTO_CREATE)
            }
        } catch (e: Exception) {
            // servis movcud deyilse, ayarlar yene de islesin
        }

        loadCurrentSettings()

        binding.btnChooseTheme.setOnClickListener { showThemePicker() }

        binding.btnSaveSettings.setOnClickListener {
            saveSettings()
            finish()
        }
    }

    private fun loadCurrentSettings() {
        val fontChoice = PrefsHelper.getFontChoice(this)
        val fontId = when (fontChoice) {
            "sans-serif-light" -> R.id.fontLight
            "sans-serif-medium" -> R.id.fontMedium
            "sans-serif-black" -> R.id.fontBlack
            "sans-serif-condensed" -> R.id.fontCondensed
            "serif" -> R.id.fontSerif
            "casual" -> R.id.fontCasual
            "cursive" -> R.id.fontCursive
            "monospace" -> R.id.fontMonospace
            "sans-serif-thin" -> R.id.fontThin
            "sans-serif-condensed-light" -> R.id.fontCondensedLight
            "sans-serif-condensed-medium" -> R.id.fontCondensedMedium
            "serif-monospace" -> R.id.fontSerifMonospace
            "sans-serif-smallcaps" -> R.id.fontSmallCaps
            else -> R.id.fontSans
        }
        binding.radioGroupFont.check(fontId)

        val eqIndex = PrefsHelper.getEqualizerPreset(this)
        val eqId = when (eqIndex) {
            1 -> R.id.eqBass
            2 -> R.id.eqHipHop
            3 -> R.id.eqPop
            4 -> R.id.eqRock
            else -> R.id.eqFlat
        }
        binding.radioGroupEqualizer.check(eqId)

        updateSelectedThemeLabel()
    }

    private fun updateSelectedThemeLabel() {
        try {
            val theme = ThemeHelper.getSelected(this)
            binding.tvSelectedTheme.text = getString(R.string.selected_theme_format, theme.name)
        } catch (e: Exception) {
            binding.tvSelectedTheme.text = ""
        }
    }

    private fun showThemePicker() {
        try {
            val names = ThemeHelper.themes.map { it.name }.toTypedArray()
            val current = PrefsHelper.getThemeIndex(this)
            AlertDialog.Builder(this)
                .setTitle(getString(R.string.choose_theme))
                .setSingleChoiceItems(names, current) { dialog, which ->
                    PrefsHelper.setThemeIndex(this, which)
                    updateSelectedThemeLabel()
                    dialog.dismiss()
                }
                .show()
        } catch (e: Exception) {
            // dialoq acila bilmese, tetbiq davam etsin
        }
    }

    private fun saveSettings() {
        val fontKey = when (binding.radioGroupFont.checkedRadioButtonId) {
            R.id.fontLight -> "sans-serif-light"
            R.id.fontMedium -> "sans-serif-medium"
            R.id.fontBlack -> "sans-serif-black"
            R.id.fontCondensed -> "sans-serif-condensed"
            R.id.fontSerif -> "serif"
            R.id.fontCasual -> "casual"
            R.id.fontCursive -> "cursive"
            R.id.fontMonospace -> "monospace"
            R.id.fontThin -> "sans-serif-thin"
            R.id.fontCondensedLight -> "sans-serif-condensed-light"
            R.id.fontCondensedMedium -> "sans-serif-condensed-medium"
            R.id.fontSerifMonospace -> "serif-monospace"
            R.id.fontSmallCaps -> "sans-serif-smallcaps"
            else -> "sans-serif"
        }
        PrefsHelper.setFontChoice(this, fontKey)

        val eqIndex = when (binding.radioGroupEqualizer.checkedRadioButtonId) {
            R.id.eqBass -> 1
            R.id.eqHipHop -> 2
            R.id.eqPop -> 3
            R.id.eqRock -> 4
            else -> 0
        }
        PrefsHelper.setEqualizerPreset(this, eqIndex)

        try {
            playbackService?.applyStoredPreset()
        } catch (e: Exception) {
            // preset tetbiq edile bilmese, ayarlar yene de saxlanilsin
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isBound) {
            try {
                unbindService(connection)
            } catch (e: Exception) {
                // artiq bagli olmaya biler
            }
            isBound = false
        }
    }
}
