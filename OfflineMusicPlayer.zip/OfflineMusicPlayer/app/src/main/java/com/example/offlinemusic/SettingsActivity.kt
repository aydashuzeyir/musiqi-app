package com.example.offlinemusic

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import androidx.appcompat.app.AppCompatActivity
import com.example.offlinemusic.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private var playbackService: PlaybackService? = null
    private var isBound = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as PlaybackService.LocalBinder
            playbackService = binder.getService()
            isBound = true
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            isBound = false
            playbackService = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Intent(this, PlaybackService::class.java).also { intent ->
            bindService(intent, connection, Context.BIND_AUTO_CREATE)
        }

        loadCurrentSettings()

        binding.btnSaveSettings.setOnClickListener {
            saveSettings()
            finish()
        }
    }

    private fun loadCurrentSettings() {
        val fontChoice = PrefsHelper.getFontChoice(this)
        val fontId = when (fontChoice) {
            "sans-serif-light" -> R.id.fontLight
            "sans-serif-medium" -> R.id.fontMedium
            "sans-serif-black" -> R.id.fontBlack
            "sans-serif-condensed" -> R.id.fontCondensed
            "serif" -> R.id.fontSerif
            "casual" -> R.id.fontCasual
            "cursive" -> R.id.fontCursive
            "monospace" -> R.id.fontMonospace
            else -> R.id.fontSans
        }
        binding.radioGroupFont.check(fontId)

        val eqIndex = PrefsHelper.getEqualizerPreset(this)
        val eqId = when (eqIndex) {
            1 -> R.id.eqBass
            2 -> R.id.eqHipHop
            3 -> R.id.eqPop
            4 -> R.id.eqRock
            else -> R.id.eqFlat
        }
        binding.radioGroupEqualizer.check(eqId)

        val themeIndex = PrefsHelper.getThemeIndex(this)
        val themeId = when (themeIndex) {
            0 -> R.id.themeBlack
            1 -> R.id.themeWhite
            2 -> R.id.themeSky
            3 -> R.id.themeGreen
            4 -> R.id.themeRed
            5 -> R.id.themeYellow
            else -> R.id.themePurple
        }
        binding.radioGroupTheme.check(themeId)
    }

    private fun saveSettings() {
        val fontKey = when (binding.radioGroupFont.checkedRadioButtonId) {
            R.id.fontLight -> "sans-serif-light"
            R.id.fontMedium -> "sans-serif-medium"
            R.id.fontBlack -> "sans-serif-black"
            R.id.fontCondensed -> "sans-serif-condensed"
            R.id.fontSerif -> "serif"
            R.id.fontCasual -> "casual"
            R.id.fontCursive -> "cursive"
            R.id.fontMonospace -> "monospace"
            else -> "sans-serif"
        }
        PrefsHelper.setFontChoice(this, fontKey)

        val eqIndex = when (binding.radioGroupEqualizer.checkedRadioButtonId) {
            R.id.eqBass -> 1
            R.id.eqHipHop -> 2
            R.id.eqPop -> 3
            R.id.eqRock -> 4
            else -> 0
        }
        PrefsHelper.setEqualizerPreset(this, eqIndex)

        val themeIndex = when (binding.radioGroupTheme.checkedRadioButtonId) {
            R.id.themeWhite -> 1
            R.id.themeSky -> 2
            R.id.themeGreen -> 3
            R.id.themeRed -> 4
            R.id.themeYellow -> 5
            R.id.themePurple -> 6
            else -> 0
        }
        PrefsHelper.setThemeIndex(this, themeIndex)

        playbackService?.applyStoredPreset()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isBound) {
            unbindService(connection)
            isBound = false
        }
    }
}
