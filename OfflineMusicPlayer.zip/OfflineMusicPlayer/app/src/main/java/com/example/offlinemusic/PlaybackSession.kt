package com.example.offlinemusic

/**
 * MainActivity ve NowPlayingActivity arasinda cari calinan siyahi/index-i
 * paylasmaq ucun sade obyekt.
 */
object PlaybackSession {
    var songs: List<Song> = emptyList()
    var currentIndex: Int = -1
}
