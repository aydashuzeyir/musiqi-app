package com.example.offlinemusic

import android.app.*
import android.content.Intent
import android.media.MediaPlayer
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/**
 * Bu servis musiqini arxa fonda calmaga davam etdirir.
 * Hec bir sebeke/internet elaqesi yoxdur - butun fayllar cihazdandir.
 * Ekvalayzer (ses effektleri) de burada idare olunur.
 */
class PlaybackService : Service() {

    private val binder = LocalBinder()
    var mediaPlayer: MediaPlayer? = null
        private set
    var currentSong: Song? = null
        private set
    var onCompletionListener: (() -> Unit)? = null

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null

    inner class LocalBinder : Binder() {
        fun getService(): PlaybackService = this@PlaybackService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Sistem yaddas ucun servisi bagladiqda avtomatik yeniden basladsin
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    fun playSong(song: Song) {
        mediaPlayer?.release()
        releaseEffects()
        currentSong = song
        mediaPlayer = MediaPlayer().apply {
            setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            setDataSource(this@PlaybackService, Uri.parse(song.uriString))
            setOnPreparedListener {
                setupEffects(audioSessionId)
                start()
            }
            setOnCompletionListener { onCompletionListener?.invoke() }
            prepareAsync()
        }
        startForeground(NOTIFICATION_ID, buildNotification(song, true))
    }

    fun togglePlayPause(): Boolean {
        val mp = mediaPlayer ?: return false
        return if (mp.isPlaying) {
            mp.pause()
            currentSong?.let { startForeground(NOTIFICATION_ID, buildNotification(it, false)) }
            false
        } else {
            mp.start()
            currentSong?.let { startForeground(NOTIFICATION_ID, buildNotification(it, true)) }
            true
        }
    }

    fun isPlaying(): Boolean = mediaPlayer?.isPlaying == true

    fun seekTo(position: Int) {
        mediaPlayer?.seekTo(position)
    }

    fun getCurrentPosition(): Int = mediaPlayer?.currentPosition ?: 0

    fun getDuration(): Int = mediaPlayer?.duration ?: 0

    // ---- Ekvalayzer ----

    private fun setupEffects(sessionId: Int) {
        try {
            equalizer = Equalizer(0, sessionId).apply { enabled = true }
            bassBoost = BassBoost(0, sessionId).apply { enabled = true }
            applyStoredPreset()
        } catch (e: Exception) {
            // Bezi cihazlarda audio effektleri desteklenmeye biler, tetbiqi bloklama
        }
    }

    fun applyStoredPreset() {
        val presetIndex = PrefsHelper.getEqualizerPreset(applicationContext)
        applyPreset(presetIndex)
    }

    /**
     * 0 = Flat, 1 = Bass Boost, 2 = Hip-Hop, 3 = Pop, 4 = Rock
     */
    private fun applyPreset(index: Int) {
        val eq = equalizer ?: return
        val bb = bassBoost
        val bands = eq.numberOfBands
        if (bands <= 0) return
        val range = eq.bandLevelRange
        val minLevel = range[0]
        val maxLevel = range[1]

        fun scaledLevel(fraction: Double): Short {
            val level = (maxLevel * fraction).toInt()
            return level.coerceIn(minLevel.toInt(), maxLevel.toInt()).toShort()
        }

        bb?.setStrength(0)

        for (i in 0 until bands) {
            val positionFraction = if (bands > 1) i.toDouble() / (bands - 1) else 0.0
            val isLow = positionFraction < 0.33
            val isMid = positionFraction in 0.33..0.66
            val isHigh = positionFraction > 0.66

            val level: Short = when (index) {
                1 -> { // Bass Boost - maksimum guc
                    bb?.setStrength(1000)
                    if (isLow) scaledLevel(1.0) else if (isMid) scaledLevel(-0.1) else scaledLevel(-0.15)
                }
                2 -> { // Hip-Hop: guclu bass, azalmis orta, artmis tepe
                    bb?.setStrength(700)
                    when {
                        isLow -> scaledLevel(0.75)
                        isMid -> scaledLevel(-0.2)
                        else -> scaledLevel(0.35)
                    }
                }
                3 -> { // Pop: orta tezlikler (vokal) one cixir
                    when {
                        isLow -> scaledLevel(0.15)
                        isMid -> scaledLevel(0.45)
                        else -> scaledLevel(0.25)
                    }
                }
                4 -> { // Rock: bass ve tepe yuksek, orta bir az asagi
                    bb?.setStrength(500)
                    when {
                        isLow -> scaledLevel(0.6)
                        isMid -> scaledLevel(-0.1)
                        else -> scaledLevel(0.5)
                    }
                }
                else -> 0 // Flat
            }
            try {
                eq.setBandLevel(i.toShort(), level)
            } catch (e: Exception) {
                // bant seviyyesi qoyula bilmedi, davam et
            }
        }
    }

    private fun releaseEffects() {
        equalizer?.release()
        equalizer = null
        bassBoost?.release()
        bassBoost = null
    }

    private fun buildNotification(song: Song, isPlaying: Boolean): Notification {
        return NotificationCompatBuilderHelper.build(this, song, isPlaying)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Musiqi Pleyeri",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        releaseEffects()
        mediaPlayer?.release()
        mediaPlayer = null
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "music_playback_channel"
        const val NOTIFICATION_ID = 1
    }
}
