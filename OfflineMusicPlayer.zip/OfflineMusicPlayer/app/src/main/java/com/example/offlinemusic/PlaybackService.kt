package com.example.offlinemusic

import android.app.*
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.IBinder

/**
 * Bu servis musiqini arxa fonda calmaga davam etdirir.
 * Hec bir sebeke/internet elaqesi yoxdur - butun fayllar cihazdandir.
 */
class PlaybackService : Service() {

    private val binder = LocalBinder()
    var mediaPlayer: MediaPlayer? = null
        private set
    var currentSong: Song? = null
        private set
    var onCompletionListener: (() -> Unit)? = null

    inner class LocalBinder : Binder() {
        fun getService(): PlaybackService = this@PlaybackService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    fun playSong(song: Song) {
        mediaPlayer?.release()
        currentSong = song
        mediaPlayer = MediaPlayer().apply {
            setDataSource(this@PlaybackService, Uri.parse(song.uriString))
            setOnPreparedListener { start() }
            setOnCompletionListener { onCompletionListener?.invoke() }
            prepareAsync()
        }
        startForeground(NOTIFICATION_ID, buildNotification(song, true))
    }

    fun togglePlayPause(): Boolean {
        val mp = mediaPlayer ?: return false
        return if (mp.isPlaying) {
            mp.pause()
            currentSong?.let { startForeground(NOTIFICATION_ID, buildNotification(it, false)) }
            false
        } else {
            mp.start()
            currentSong?.let { startForeground(NOTIFICATION_ID, buildNotification(it, true)) }
            true
        }
    }

    fun isPlaying(): Boolean = mediaPlayer?.isPlaying == true

    fun seekTo(position: Int) {
        mediaPlayer?.seekTo(position)
    }

    fun getCurrentPosition(): Int = mediaPlayer?.currentPosition ?: 0

    fun getDuration(): Int = mediaPlayer?.duration ?: 0

    private fun buildNotification(song: Song, isPlaying: Boolean): Notification {
        return NotificationCompatBuilderHelper.build(this, song, isPlaying)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Musiqi Pleyeri",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        mediaPlayer?.release()
        mediaPlayer = null
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "music_playback_channel"
        const val NOTIFICATION_ID = 1
    }
}
