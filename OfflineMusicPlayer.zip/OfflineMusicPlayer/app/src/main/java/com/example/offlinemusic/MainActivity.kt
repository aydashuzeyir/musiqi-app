package com.example.offlinemusic

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.SeekBar
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.offlinemusic.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var songs: List<Song> = emptyList()
    private lateinit var adapter: SongAdapter
    private var currentIndex: Int = -1

    private var playbackService: PlaybackService? = null
    private var isBound = false

    private val handler = Handler(Looper.getMainLooper())
    private val updateSeekBarTask = object : Runnable {
        override fun run() {
            playbackService?.let { service ->
                if (service.isPlaying()) {
                    binding.seekBar.max = service.getDuration()
                    binding.seekBar.progress = service.getCurrentPosition()
                }
            }
            handler.postDelayed(this, 500)
        }
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as PlaybackService.LocalBinder
            playbackService = binder.getService()
            isBound = true
            playbackService?.onCompletionListener = { playNext() }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            isBound = false
            playbackService = null
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            loadSongs()
        } else {
            showPermissionNeeded()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recyclerSongs.layoutManager = LinearLayoutManager(this)

        binding.btnGrantPermission.setOnClickListener { requestAudioPermission() }
        binding.btnPlayPause.setOnClickListener { togglePlayPause() }
        binding.btnNext.setOnClickListener { playNext() }
        binding.btnPrevious.setOnClickListener { playPrevious() }

        binding.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) playbackService?.seekTo(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        Intent(this, PlaybackService::class.java).also { intent ->
            bindService(intent, connection, Context.BIND_AUTO_CREATE)
        }

        checkPermissionAndLoad()
    }

    private fun audioPermission(): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            android.Manifest.permission.READ_MEDIA_AUDIO
        } else {
            android.Manifest.permission.READ_EXTERNAL_STORAGE
        }
    }

    private fun checkPermissionAndLoad() {
        val permission = audioPermission()
        if (ContextCompat.checkSelfPermission(this, permission) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            loadSongs()
        } else {
            requestAudioPermission()
        }
    }

    private fun requestAudioPermission() {
        permissionLauncher.launch(audioPermission())
    }

    private fun showPermissionNeeded() {
        binding.tvEmpty.text = getString(R.string.permission_needed)
        binding.tvEmpty.visibility = android.view.View.VISIBLE
        binding.btnGrantPermission.visibility = android.view.View.VISIBLE
        binding.recyclerSongs.visibility = android.view.View.GONE
    }

    private fun loadSongs() {
        songs = MusicScanner.scan(this)
        binding.btnGrantPermission.visibility = android.view.View.GONE

        if (songs.isEmpty()) {
            binding.tvEmpty.text = getString(R.string.no_songs)
            binding.tvEmpty.visibility = android.view.View.VISIBLE
            binding.recyclerSongs.visibility = android.view.View.GONE
            return
        }

        binding.tvEmpty.visibility = android.view.View.GONE
        binding.recyclerSongs.visibility = android.view.View.VISIBLE

        adapter = SongAdapter(songs) { position -> playSongAt(position) }
        binding.recyclerSongs.adapter = adapter
    }

    private fun playSongAt(index: Int) {
        if (index !in songs.indices) return
        currentIndex = index
        val song = songs[index]
        playbackService?.playSong(song)
        adapter.currentPlayingIndex = index

        binding.playerBar.visibility = android.view.View.VISIBLE
        binding.tvNowPlayingTitle.text = song.title
        binding.tvNowPlayingArtist.text = song.artist
        binding.btnPlayPause.setImageResource(R.drawable.ic_pause)

        handler.removeCallbacks(updateSeekBarTask)
        handler.post(updateSeekBarTask)
    }

    private fun togglePlayPause() {
        if (currentIndex == -1) {
            if (songs.isNotEmpty()) playSongAt(0)
            return
        }
        val nowPlaying = playbackService?.togglePlayPause() ?: false
        binding.btnPlayPause.setImageResource(
            if (nowPlaying) R.drawable.ic_pause else R.drawable.ic_play
        )
    }

    private fun playNext() {
        if (songs.isEmpty()) return
        val next = if (currentIndex + 1 < songs.size) currentIndex + 1 else 0
        playSongAt(next)
    }

    private fun playPrevious() {
        if (songs.isEmpty()) return
        val prev = if (currentIndex - 1 >= 0) currentIndex - 1 else songs.size - 1
        playSongAt(prev)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(updateSeekBarTask)
        if (isBound) {
            unbindService(connection)
            isBound = false
        }
    }
}
