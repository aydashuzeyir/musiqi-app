package com.example.offlinemusic

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.offlinemusic.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var allSongs: List<Song> = emptyList()
    private var activeSongs: List<Song> = emptyList()
    private lateinit var adapter: SongAdapter
    private var currentIndex: Int = -1

    private var playbackService: PlaybackService? = null
    private var isBound = false

    private val handler = Handler(Looper.getMainLooper())
    private val updateSeekBarTask = object : Runnable {
        override fun run() {
            playbackService?.let { service ->
                if (service.isPlaying()) {
                    binding.seekBar.max = service.getDuration()
                    binding.seekBar.progress = service.getCurrentPosition()
                }
            }
            handler.postDelayed(this, 500)
        }
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as PlaybackService.LocalBinder
            playbackService = binder.getService()
            isBound = true
            playbackService?.onCompletionListener = { playNext() }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            isBound = false
            playbackService = null
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            loadSongs()
        } else {
            showPermissionNeeded()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recyclerSongs.layoutManager = LinearLayoutManager(this)
        binding.recyclerSongs.isNestedScrollingEnabled = false

        binding.btnGrantPermission.setOnClickListener { requestAudioPermission() }
        binding.btnPlayPause.setOnClickListener { togglePlayPause() }
        binding.btnHeroPlay.setOnClickListener { togglePlayPause() }
        binding.btnHeroShuffle.setOnClickListener { playRandom() }
        binding.btnNext.setOnClickListener { playNext() }
        binding.btnPrevious.setOnClickListener { playPrevious() }
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.catSongs.setOnClickListener { selectCategory(CategoryMode.ALL) }
        binding.catFavorites.setOnClickListener { selectCategory(CategoryMode.FAVORITES) }
        binding.catRecent.setOnClickListener { selectCategory(CategoryMode.RECENT) }
        binding.catPlaylists.setOnClickListener { selectCategory(CategoryMode.PLAYLISTS) }

        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    setHomeSectionsVisible(true)
                    selectCategory(CategoryMode.RECENT)
                    true
                }
                R.id.nav_songs -> {
                    setHomeSectionsVisible(false)
                    binding.tvSectionTitle.text = getString(R.string.nav_songs)
                    showSongList(allSongs.sortedBy { it.title })
                    true
                }
                R.id.nav_albums -> {
                    setHomeSectionsVisible(false)
                    binding.tvSectionTitle.text = getString(R.string.nav_albums)
                    showSongList(allSongs.sortedBy { it.album })
                    true
                }
                R.id.nav_artists -> {
                    setHomeSectionsVisible(false)
                    binding.tvSectionTitle.text = getString(R.string.nav_artists)
                    showSongList(allSongs.sortedBy { it.artist })
                    true
                }
                R.id.nav_settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    false
                }
                else -> false
            }
        }

        binding.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) playbackService?.seekTo(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // Servisi baslat ki, activity bagli olsa da musiqi arxa fonda davam etsin
        Intent(this, PlaybackService::class.java).also { intent ->
            startService(intent)
            bindService(intent, connection, Context.BIND_AUTO_CREATE)
        }

        checkPermissionAndLoad()
    }

    private fun audioPermission(): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            android.Manifest.permission.READ_MEDIA_AUDIO
        } else {
            android.Manifest.permission.READ_EXTERNAL_STORAGE
        }
    }

    private fun checkPermissionAndLoad() {
        val permission = audioPermission()
        if (ContextCompat.checkSelfPermission(this, permission) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            loadSongs()
        } else {
            requestAudioPermission()
        }
    }

    private fun requestAudioPermission() {
        permissionLauncher.launch(audioPermission())
    }

    private fun showPermissionNeeded() {
        binding.tvEmpty.text = getString(R.string.permission_needed)
        binding.tvEmpty.visibility = android.view.View.VISIBLE
        binding.btnGrantPermission.visibility = android.view.View.VISIBLE
        binding.recyclerSongs.visibility = android.view.View.GONE
    }

    private fun loadSongs() {
        binding.progressLoading.visibility = android.view.View.VISIBLE
        Thread {
            val result = MusicScanner.scan(this)
            handler.post {
                binding.progressLoading.visibility = android.view.View.GONE
                allSongs = result
                binding.btnGrantPermission.visibility = android.view.View.GONE

                if (allSongs.isEmpty()) {
                    binding.tvEmpty.text = getString(R.string.no_songs)
                    binding.tvEmpty.visibility = android.view.View.VISIBLE
                    binding.recyclerSongs.visibility = android.view.View.GONE
                    return@post
                }

                binding.tvEmpty.visibility = android.view.View.GONE
                binding.recyclerSongs.visibility = android.view.View.VISIBLE
                selectCategory(CategoryMode.RECENT)
            }
        }.start()
    }

    private enum class CategoryMode { ALL, FAVORITES, RECENT, PLAYLISTS }

    private fun selectCategory(mode: CategoryMode) {
        when (mode) {
            CategoryMode.ALL -> {
                binding.tvSectionTitle.text = getString(R.string.category_songs)
                showSongList(allSongs)
            }
            CategoryMode.FAVORITES -> {
                binding.tvSectionTitle.text = getString(R.string.category_favorites)
                val favIds = PrefsHelper.getFavorites(this)
                showSongList(allSongs.filter { favIds.contains(it.id.toString()) })
            }
            CategoryMode.RECENT -> {
                binding.tvSectionTitle.text = getString(R.string.recent_section)
                val recentIds = PrefsHelper.getRecentIds(this)
                val bySongId = allSongs.associateBy { it.id }
                val recentSongs = recentIds.mapNotNull { bySongId[it] }
                showSongList(if (recentSongs.isNotEmpty()) recentSongs else allSongs)
            }
            CategoryMode.PLAYLISTS -> {
                Toast.makeText(this, getString(R.string.playlists_coming_soon), Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setHomeSectionsVisible(visible: Boolean) {
        val visibility = if (visible) android.view.View.VISIBLE else android.view.View.GONE
        binding.heroCard.visibility = visibility
        binding.categoryRow.visibility = visibility
    }

    private fun showSongList(list: List<Song>) {
        activeSongs = list
        if (list.isEmpty()) {
            binding.tvEmpty.text = getString(R.string.no_songs)
            binding.tvEmpty.visibility = android.view.View.VISIBLE
            binding.recyclerSongs.visibility = android.view.View.GONE
        } else {
            binding.tvEmpty.visibility = android.view.View.GONE
            binding.recyclerSongs.visibility = android.view.View.VISIBLE
        }

        // Cari calinan mahninin yeni siyahidaki yerini tap
        val playingId = playbackService?.currentSong?.id
        currentIndex = if (playingId != null) list.indexOfFirst { it.id == playingId } else -1

        adapter = SongAdapter(
            this,
            list,
            onClick = { position -> playSongAt(position) },
            onFavoriteClick = { position ->
                val song = activeSongs[position]
                PrefsHelper.toggleFavorite(this, song.id)
            }
        )
        adapter.currentPlayingIndex = currentIndex
        binding.recyclerSongs.adapter = adapter
    }

    private fun playSongAt(index: Int) {
        if (index !in activeSongs.indices) return
        currentIndex = index
        val song = activeSongs[index]
        playbackService?.playSong(song)
        adapter.currentPlayingIndex = index
        PrefsHelper.addRecent(this, song.id)

        binding.playerBar.visibility = android.view.View.VISIBLE
        binding.tvNowPlayingTitle.text = song.title
        binding.tvNowPlayingArtist.text = song.artist
        binding.btnPlayPause.setImageResource(R.drawable.ic_pause)

        binding.tvHeroTitle.text = song.title
        binding.tvHeroArtist.text = song.artist
        binding.btnHeroPlay.setImageResource(R.drawable.ic_pause)

        binding.ivMiniAlbumArt.setImageResource(R.drawable.ic_music_note)
        Thread {
            val bitmap = try {
                val uri = android.content.ContentUris.withAppendedId(
                    android.net.Uri.parse("content://media/external/audio/albumart"), song.albumId
                )
                android.graphics.BitmapFactory.decodeStream(contentResolver.openInputStream(uri))
            } catch (e: Exception) {
                null
            }
            handler.post {
                if (bitmap != null) binding.ivMiniAlbumArt.setImageBitmap(bitmap)
            }
        }.start()

        handler.removeCallbacks(updateSeekBarTask)
        handler.post(updateSeekBarTask)
    }

    private fun playRandom() {
        if (activeSongs.isEmpty()) return
        val randomIndex = activeSongs.indices.random()
        playSongAt(randomIndex)
    }

    private fun togglePlayPause() {
        if (currentIndex == -1) {
            if (activeSongs.isNotEmpty()) playSongAt(0)
            return
        }
        val nowPlaying = playbackService?.togglePlayPause() ?: false
        val icon = if (nowPlaying) R.drawable.ic_pause else R.drawable.ic_play
        binding.btnPlayPause.setImageResource(icon)
        binding.btnHeroPlay.setImageResource(icon)
    }

    private fun playNext() {
        if (activeSongs.isEmpty()) return
        val next = if (currentIndex + 1 < activeSongs.size) currentIndex + 1 else 0
        playSongAt(next)
    }

    private fun playPrevious() {
        if (activeSongs.isEmpty()) return
        val prev = if (currentIndex - 1 >= 0) currentIndex - 1 else activeSongs.size - 1
        playSongAt(prev)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(updateSeekBarTask)
        if (isBound) {
            unbindService(connection)
            isBound = false
        }
    }
}
