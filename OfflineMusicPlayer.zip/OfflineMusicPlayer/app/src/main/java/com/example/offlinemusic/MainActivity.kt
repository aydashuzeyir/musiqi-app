package com.example.offlinemusic

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.GestureDetector
import android.view.MotionEvent
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.GridLayoutManager
import com.example.offlinemusic.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var allSongs: List<Song> = emptyList()
    private var activeSongs: List<Song> = emptyList()
    private lateinit var adapter: SongAdapter
    private var currentIndex: Int = -1

    private var playbackService: PlaybackService? = null
    private var isBound = false

    private val handler = Handler(Looper.getMainLooper())
    private val updateSeekBarTask = object : Runnable {
        override fun run() {
            playbackService?.let { service ->
                if (service.isPlaying()) {
                    binding.seekBar.max = service.getDuration()
                    binding.seekBar.progress = service.getCurrentPosition()
                }
            }
            handler.postDelayed(this, 500)
        }
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as PlaybackService.LocalBinder
            playbackService = binder.getService()
            isBound = true
            playbackService?.onCompletionListener = { playNext() }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            isBound = false
            playbackService = null
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            loadSongs()
        } else {
            showPermissionNeeded()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recyclerSongs.layoutManager = LinearLayoutManager(this)
        binding.recyclerSongs.isNestedScrollingEnabled = false
        applyGridSize()

        binding.btnGrantPermission.setOnClickListener { requestAudioPermission() }
        binding.btnPlayPause.setOnClickListener { togglePlayPause() }
        binding.btnHeroPlay.setOnClickListener { togglePlayPause() }
        binding.btnHeroShuffle.setOnClickListener { playRandom() }
        binding.btnThemePicker.setOnClickListener { showThemePicker() }
        binding.btnNext.setOnClickListener { playNext() }
        binding.btnPrevious.setOnClickListener { playPrevious() }
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.btnGridSize.setOnClickListener { showGridSizePicker() }
        binding.nowPlayingInfo.setOnClickListener { openNowPlaying() }
        binding.heroCard.setOnClickListener { openNowPlaying() }

        binding.catSongs.setOnClickListener { selectCategory(CategoryMode.ALL) }
        binding.catFavorites.setOnClickListener { selectCategory(CategoryMode.FAVORITES) }
        binding.catRecent.setOnClickListener { selectCategory(CategoryMode.RECENT) }
        binding.catPlaylists.setOnClickListener { selectCategory(CategoryMode.PLAYLISTS) }

        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    setHomeSectionsVisible(true)
                    selectCategory(CategoryMode.RECENT)
                    true
                }
                R.id.nav_songs -> {
                    setHomeSectionsVisible(false)
                    binding.tvSectionTitle.text = getString(R.string.nav_songs)
                    showSongList(allSongs.sortedBy { it.title })
                    true
                }
                R.id.nav_albums -> {
                    setHomeSectionsVisible(false)
                    binding.tvSectionTitle.text = getString(R.string.nav_albums)
                    showSongList(allSongs.sortedBy { it.album })
                    true
                }
                R.id.nav_artists -> {
                    setHomeSectionsVisible(false)
                    binding.tvSectionTitle.text = getString(R.string.nav_artists)
                    showSongList(allSongs.sortedBy { it.artist })
                    true
                }
                R.id.nav_settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    false
                }
                else -> false
            }
        }

        binding.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) playbackService?.seekTo(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // Servisi baslat ki, activity bagli olsa da musiqi arxa fonda davam etsin
        Intent(this, PlaybackService::class.java).also { intent ->
            startService(intent)
            bindService(intent, connection, Context.BIND_AUTO_CREATE)
        }

        val miniPlayerGesture = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(
                e1: MotionEvent?, e2: MotionEvent,
                velocityX: Float, velocityY: Float
            ): Boolean {
                try {
                    val diffX = e2.x - (e1?.x ?: e2.x)
                    if (Math.abs(diffX) > 100 && Math.abs(velocityX) > 150) {
                        if (diffX < 0) playNext() else playPrevious()
                        return true
                    }
                } catch (e: Exception) {
                    // xeta olsa, sadece sureti gormezden gel
                }
                return false
            }
        })
        binding.nowPlayingInfo.setOnTouchListener { _, event -> miniPlayerGesture.onTouchEvent(event) }

        binding.etSearch.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                performSearch(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })

        checkPermissionAndLoad()
        applyTheme()
        applyFont()
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
        applyFont()
    }

    private fun showThemePicker() {
        try {
            val names = ThemeHelper.themes.map { it.name }.toTypedArray()
            val current = PrefsHelper.getThemeIndex(this)
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(getString(R.string.theme_section))
                .setSingleChoiceItems(names, current) { dialog, which ->
                    PrefsHelper.setThemeIndex(this, which)
                    applyTheme()
                    dialog.dismiss()
                }
                .show()
        } catch (e: Exception) {
            // Dialoq acila bilmese tetbiq davam etsin
        }
    }

    private fun applyFont() {
        try {
            val fontKey = PrefsHelper.getFontChoice(this)
            val typeface = android.graphics.Typeface.create(fontKey, android.graphics.Typeface.NORMAL)
            binding.tvHeader.typeface = typeface
            binding.tvHeroTitle.typeface = typeface
            binding.tvSectionTitle.typeface = typeface
            binding.tvNowPlayingTitle.typeface = typeface
        } catch (e: Exception) {
            // Sift tetbiq edile bilmese, default sift ile davam etsin
        }
    }

    private fun applyTheme() {
        try {
            val theme = ThemeHelper.getSelected(this)
            val density = resources.displayMetrics.density

            val heroDrawable = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(theme.dark, theme.primary, ContextCompat.getColor(this, R.color.surface_dark))
            )
            heroDrawable.cornerRadius = 20f * density
            binding.heroCard.background = heroDrawable

            val playCircle1 = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(theme.primary)
            }
            binding.btnHeroPlay.background = playCircle1

            val playCircle2 = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(theme.primary)
            }
            binding.btnPlayPause.background = playCircle2

            binding.seekBar.progressTintList = ColorStateList.valueOf(theme.primary)
            binding.seekBar.thumbTintList = ColorStateList.valueOf(theme.light)

            binding.tvHeroLabel.setTextColor(theme.light)

            val navStates = arrayOf(
                intArrayOf(android.R.attr.state_checked),
                intArrayOf(-android.R.attr.state_checked)
            )
            val navColors = ColorStateList(
                navStates,
                intArrayOf(theme.light, ContextCompat.getColor(this, R.color.text_secondary))
            )
            binding.bottomNav.itemIconTintList = navColors
            binding.bottomNav.itemTextColor = navColors

            val searchBg = GradientDrawable().apply {
                setColor(ContextCompat.getColor(this@MainActivity, R.color.surface_dark))
                cornerRadius = 14f * density
                setStroke((1.5f * density).toInt(), theme.primary)
            }
            binding.etSearch.background = searchBg
            binding.etSearch.setHintTextColor(theme.light)
            binding.etSearch.highlightColor = theme.primary
            try {
                binding.etSearch.textCursorDrawable = null
            } catch (e: Exception) {
                // bezi cihazlarda destekelenmeye biler
            }
        } catch (e: Exception) {
            // Tema tetbiq edile bilmese, tetbiq normal davam etsin, cokmesin
        }
    }

    private fun audioPermission(): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            android.Manifest.permission.READ_MEDIA_AUDIO
        } else {
            android.Manifest.permission.READ_EXTERNAL_STORAGE
        }
    }

    private fun checkPermissionAndLoad() {
        val permission = audioPermission()
        if (ContextCompat.checkSelfPermission(this, permission) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            loadSongs()
        } else {
            requestAudioPermission()
        }
    }

    private fun requestAudioPermission() {
        permissionLauncher.launch(audioPermission())
    }

    private fun showPermissionNeeded() {
        binding.tvEmpty.text = getString(R.string.permission_needed)
        binding.tvEmpty.visibility = android.view.View.VISIBLE
        binding.btnGrantPermission.visibility = android.view.View.VISIBLE
        binding.recyclerSongs.visibility = android.view.View.GONE
    }

    private fun loadSongs() {
        binding.progressLoading.visibility = android.view.View.VISIBLE
        Thread {
            val result = MusicScanner.scan(this)
            handler.post {
                binding.progressLoading.visibility = android.view.View.GONE
                allSongs = result
                binding.tvSongCount.text = getString(R.string.song_count_format, allSongs.size)
                binding.btnGrantPermission.visibility = android.view.View.GONE

                if (allSongs.isEmpty()) {
                    binding.tvEmpty.text = getString(R.string.no_songs)
                    binding.tvEmpty.visibility = android.view.View.VISIBLE
                    binding.recyclerSongs.visibility = android.view.View.GONE
                    return@post
                }

                binding.tvEmpty.visibility = android.view.View.GONE
                binding.recyclerSongs.visibility = android.view.View.VISIBLE
                selectCategory(CategoryMode.RECENT)
            }
        }.start()
    }

    private fun performSearch(query: String) {
        try {
            if (query.isBlank()) {
                setHomeSectionsVisible(true)
                selectCategory(CategoryMode.RECENT)
                return
            }
            setHomeSectionsVisible(false)
            binding.tvSectionTitle.text = getString(R.string.search_hint)
            val lower = query.lowercase()
            val results = allSongs.filter {
                it.title.lowercase().contains(lower) || it.artist.lowercase().contains(lower)
            }
            showSongList(results)
        } catch (e: Exception) {
            // axtaris xetasi olsa, tetbiq davam etsin
        }
    }

    private enum class CategoryMode { ALL, FAVORITES, RECENT, PLAYLISTS }

    private fun selectCategory(mode: CategoryMode) {
        when (mode) {
            CategoryMode.ALL -> {
                binding.tvSectionTitle.text = getString(R.string.category_songs)
                showSongList(allSongs)
            }
            CategoryMode.FAVORITES -> {
                binding.tvSectionTitle.text = getString(R.string.category_favorites)
                val favIds = PrefsHelper.getFavorites(this)
                showSongList(allSongs.filter { favIds.contains(it.id.toString()) })
            }
            CategoryMode.RECENT -> {
                binding.tvSectionTitle.text = getString(R.string.recent_section)
                val recentIds = PrefsHelper.getRecentIds(this)
                val bySongId = allSongs.associateBy { it.id }
                val recentSongs = recentIds.mapNotNull { bySongId[it] }
                showSongList(if (recentSongs.isNotEmpty()) recentSongs else allSongs)
            }
            CategoryMode.PLAYLISTS -> {
                showPlaylistPicker()
            }
        }
    }

    private fun setHomeSectionsVisible(visible: Boolean) {
        val visibility = if (visible) android.view.View.VISIBLE else android.view.View.GONE
        binding.heroCard.visibility = visibility
        binding.categoryRow.visibility = visibility
    }

    private fun showSongList(list: List<Song>) {
        activeSongs = list
        if (list.isEmpty()) {
            binding.tvEmpty.text = getString(R.string.no_songs)
            binding.tvEmpty.visibility = android.view.View.VISIBLE
            binding.recyclerSongs.visibility = android.view.View.GONE
        } else {
            binding.tvEmpty.visibility = android.view.View.GONE
            binding.recyclerSongs.visibility = android.view.View.VISIBLE
        }

        // Cari calinan mahninin yeni siyahidaki yerini tap
        val playingId = playbackService?.currentSong?.id
        currentIndex = if (playingId != null) list.indexOfFirst { it.id == playingId } else -1

        adapter = SongAdapter(
            this,
            list,
            onClick = { position ->
                playSongAt(position)
                openNowPlaying()
            },
            onFavoriteClick = { position ->
                val song = activeSongs[position]
                PrefsHelper.toggleFavorite(this, song.id)
            },
            onLongClick = { position ->
                if (position in activeSongs.indices) showSongOptionsMenu(activeSongs[position])
            }
        )
        adapter.currentPlayingIndex = currentIndex
        binding.recyclerSongs.adapter = adapter
    }

    private fun playSongAt(index: Int) {
        if (index !in activeSongs.indices) return
        currentIndex = index
        val song = activeSongs[index]
        playbackService?.playSong(song)
        adapter.currentPlayingIndex = index
        PrefsHelper.addRecent(this, song.id)
        PlaybackSession.songs = activeSongs
        PlaybackSession.currentIndex = index

        binding.playerBar.visibility = android.view.View.VISIBLE
        binding.tvNowPlayingTitle.text = song.title
        binding.tvNowPlayingArtist.text = song.artist
        binding.btnPlayPause.setImageResource(R.drawable.ic_pause)

        binding.tvHeroTitle.text = song.title
        binding.tvHeroArtist.text = song.artist
        binding.btnHeroPlay.setImageResource(R.drawable.ic_pause)

        binding.ivMiniAlbumArt.setImageResource(R.drawable.ic_music_note)
        Thread {
            val bitmap = try {
                val uri = android.content.ContentUris.withAppendedId(
                    android.net.Uri.parse("content://media/external/audio/albumart"), song.albumId
                )
                android.graphics.BitmapFactory.decodeStream(contentResolver.openInputStream(uri))
            } catch (e: Exception) {
                null
            }
            handler.post {
                if (bitmap != null) binding.ivMiniAlbumArt.setImageBitmap(bitmap)
            }
        }.start()

        handler.removeCallbacks(updateSeekBarTask)
        handler.post(updateSeekBarTask)
    }

    private fun playRandom() {
        if (activeSongs.isEmpty()) return
        val randomIndex = if (activeSongs.size > 1) {
            var r = activeSongs.indices.random()
            while (r == currentIndex) r = activeSongs.indices.random()
            r
        } else 0
        playSongAt(randomIndex)
    }

    private fun togglePlayPause() {
        if (currentIndex == -1) {
            if (activeSongs.isNotEmpty()) playSongAt(0)
            return
        }
        val nowPlaying = playbackService?.togglePlayPause() ?: false
        val icon = if (nowPlaying) R.drawable.ic_pause else R.drawable.ic_play
        binding.btnPlayPause.setImageResource(icon)
        binding.btnHeroPlay.setImageResource(icon)
    }

    private fun playNext() {
        if (activeSongs.isEmpty()) return
        val next = if (currentIndex + 1 < activeSongs.size) currentIndex + 1 else 0
        playSongAt(next)
    }

    private fun playPrevious() {
        if (activeSongs.isEmpty()) return
        val prev = if (currentIndex - 1 >= 0) currentIndex - 1 else activeSongs.size - 1
        playSongAt(prev)
    }

    private fun applyGridSize() {
        try {
            val size = PrefsHelper.getGridSize(this).coerceIn(1, 4)
            binding.recyclerSongs.layoutManager = if (size <= 1) {
                LinearLayoutManager(this)
            } else {
                GridLayoutManager(this, size)
            }
        } catch (e: Exception) {
            binding.recyclerSongs.layoutManager = LinearLayoutManager(this)
        }
    }

    private fun showGridSizePicker() {
        try {
            val options = arrayOf("1", "2", "3", "4")
            val current = (PrefsHelper.getGridSize(this) - 1).coerceIn(0, 3)
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(getString(R.string.grid_size_title))
                .setSingleChoiceItems(options, current) { dialog, which ->
                    PrefsHelper.setGridSize(this, which + 1)
                    applyGridSize()
                    dialog.dismiss()
                }
                .show()
        } catch (e: Exception) {
            // dialoq acila bilmese, tetbiq davam etsin
        }
    }

    private fun openNowPlaying() {
        if (currentIndex == -1 || activeSongs.isEmpty()) {
            Toast.makeText(this, "Mahnı seçilməyib", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(Intent(this, NowPlayingActivity::class.java))
        } catch (e: Exception) {
            Toast.makeText(this, "Xəta: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showPlaylistPicker() {
        try {
            val names = PrefsHelper.getPlaylistNames(this).sorted().toMutableList()
            names.add(getString(R.string.create_playlist))
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(getString(R.string.category_playlists))
                .setItems(names.toTypedArray()) { _, which ->
                    if (which == names.size - 1) {
                        promptNewPlaylistName { newName ->
                            binding.tvSectionTitle.text = newName
                            showSongList(emptyList())
                        }
                    } else {
                        val playlistName = names[which]
                        val ids = PrefsHelper.getPlaylistSongIds(this, playlistName).toSet()
                        binding.tvSectionTitle.text = playlistName
                        showSongList(allSongs.filter { ids.contains(it.id) })
                    }
                }
                .show()
        } catch (e: Exception) {
            // dialoq acila bilmese, tetbiq davam etsin
        }
    }

    private fun promptNewPlaylistName(onCreated: (String) -> Unit) {
        try {
            val input = android.widget.EditText(this)
            input.hint = getString(R.string.playlist_name_hint)
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(getString(R.string.create_playlist))
                .setView(input)
                .setPositiveButton(getString(R.string.save)) { _, _ ->
                    val name = input.text.toString().trim()
                    if (name.isNotEmpty()) {
                        PrefsHelper.createPlaylist(this, name)
                        onCreated(name)
                    }
                }
                .setNegativeButton(getString(R.string.cancel), null)
                .show()
        } catch (e: Exception) {
            // dialoq acila bilmese, tetbiq davam etsin
        }
    }

    private fun showSongOptionsMenu(song: Song) {
        try {
            val options = arrayOf(getString(R.string.add_to_playlist), getString(R.string.delete_song))
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(song.title)
                .setItems(options) { _, which ->
                    if (which == 0) showAddToPlaylistDialog(song) else confirmDeleteSong(song)
                }
                .show()
        } catch (e: Exception) {
            confirmDeleteSong(song)
        }
    }

    private fun showAddToPlaylistDialog(song: Song) {
        try {
            val names = PrefsHelper.getPlaylistNames(this).sorted().toMutableList()
            names.add(getString(R.string.create_playlist))
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(getString(R.string.add_to_playlist))
                .setItems(names.toTypedArray()) { _, which ->
                    if (which == names.size - 1) {
                        promptNewPlaylistName { newName ->
                            PrefsHelper.addSongToPlaylist(this, newName, song.id)
                            Toast.makeText(this, getString(R.string.added_to_playlist), Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        PrefsHelper.addSongToPlaylist(this, names[which], song.id)
                        Toast.makeText(this, getString(R.string.added_to_playlist), Toast.LENGTH_SHORT).show()
                    }
                }
                .show()
        } catch (e: Exception) {
            // dialoq acila bilmese, tetbiq davam etsin
        }
    }

    private fun confirmDeleteSong(song: Song) {
        try {
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(song.title)
                .setMessage("Bu mahnını cihazdan silmək istəyirsiniz?")
                .setPositiveButton("Sil") { _, _ -> deleteSong(song) }
                .setNegativeButton("Ləğv et", null)
                .show()
        } catch (e: Exception) {
            // Dialoq acila bilmese, hec ne etme - tetbiq davam etsin
        }
    }

    private val deleteLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            Toast.makeText(this, "Mahnı silindi", Toast.LENGTH_SHORT).show()
            loadSongs()
        }
    }

    private fun deleteSong(song: Song) {
        try {
            val uri = android.net.Uri.parse(song.uriString)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val pendingIntent = android.provider.MediaStore.createDeleteRequest(
                    contentResolver, listOf(uri)
                )
                deleteLauncher.launch(
                    androidx.activity.result.IntentSenderRequest.Builder(pendingIntent.intentSender).build()
                )
            } else {
                try {
                    val rows = contentResolver.delete(uri, null, null)
                    if (rows > 0) {
                        Toast.makeText(this, "Mahnı silindi", Toast.LENGTH_SHORT).show()
                        loadSongs()
                    }
                } catch (se: SecurityException) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && se is android.app.RecoverableSecurityException) {
                        val pi = se.userAction.actionIntent
                        deleteLauncher.launch(
                            androidx.activity.result.IntentSenderRequest.Builder(pi.intentSender).build()
                        )
                    } else {
                        Toast.makeText(this, "Silmək mümkün olmadı", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Xəta baş verdi, mahnı silinmədi", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(updateSeekBarTask)
        if (isBound) {
            unbindService(connection)
            isBound = false
        }
    }
}
