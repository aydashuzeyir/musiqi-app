package com.example.offlinemusic

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.GestureDetector
import android.view.MotionEvent
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import com.example.offlinemusic.databinding.ActivityNowPlayingBinding
import java.util.concurrent.TimeUnit

class NowPlayingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNowPlayingBinding
    private var playbackService: PlaybackService? = null
    private var isBound = false
    private var styleIndex = 0
    private var shuffleOn = false
    private var repeatOn = false

    private val handler = Handler(Looper.getMainLooper())
    private val updateTask = object : Runnable {
        override fun run() {
            playbackService?.let { service ->
                if (service.isPlaying()) {
                    binding.npSeekBar.max = service.getDuration()
                    binding.npSeekBar.progress = service.getCurrentPosition()
                    binding.tvNpCurrentTime.text = formatTime(service.getCurrentPosition())
                    binding.tvNpTotalTime.text = formatTime(service.getDuration())
                }
            }
            handler.postDelayed(this, 500)
        }
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as PlaybackService.LocalBinder
            playbackService = binder.getService()
            isBound = true
            playbackService?.onCompletionListener = { playNext() }
            refreshUi()
            handler.post(updateTask)
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            isBound = false
            playbackService = null
        }
    }

    private lateinit var gestureDetector: GestureDetector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNowPlayingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnNpBack.setOnClickListener { finish() }
        binding.btnNpPlayPause.setOnClickListener { togglePlayPause() }
        binding.btnNpNext.setOnClickListener { playNext() }
        binding.btnNpPrevious.setOnClickListener { playPrevious() }
        binding.btnNpStyle.setOnClickListener { toggleStyle() }
        binding.btnNpFavorite.setOnClickListener { toggleFavorite() }
        binding.btnNpShuffle.setOnClickListener { toggleShuffle() }
        binding.btnNpRepeat.setOnClickListener { toggleRepeat() }

        binding.npSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) playbackService?.seekTo(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(
                e1: MotionEvent?, e2: MotionEvent,
                velocityX: Float, velocityY: Float
            ): Boolean {
                try {
                    val diffX = e2.x - (e1?.x ?: e2.x)
                    if (Math.abs(diffX) > 120 && Math.abs(velocityX) > 200) {
                        if (diffX < 0) playNext() else playPrevious()
                        return true
                    }
                } catch (e: Exception) {
                    // sehv olsa, sadece heric elave harekt gormezden gel
                }
                return false
            }
        })
        binding.npArtFrame.setOnTouchListener { _, event -> gestureDetector.onTouchEvent(event) }

        applyStyle()

        Intent(this, PlaybackService::class.java).also { intent ->
            bindService(intent, connection, Context.BIND_AUTO_CREATE)
        }
    }

    private fun refreshUi() {
        val song = playbackService?.currentSong ?: PlaybackSession.songs.getOrNull(PlaybackSession.currentIndex)
        if (song != null) {
            binding.tvNpTitle.text = song.title
            binding.tvNpArtist.text = song.artist
            binding.btnNpFavorite.setImageResource(
                if (PrefsHelper.isFavorite(this, song.id)) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline
            )
            binding.ivNpArt.setImageResource(R.drawable.ic_music_note)
            Thread {
                val bitmap = try {
                    val uri = android.content.ContentUris.withAppendedId(
                        android.net.Uri.parse("content://media/external/audio/albumart"), song.albumId
                    )
                    android.graphics.BitmapFactory.decodeStream(contentResolver.openInputStream(uri))
                } catch (e: Exception) {
                    null
                }
                handler.post { if (bitmap != null) binding.ivNpArt.setImageBitmap(bitmap) }
            }.start()
        }
        val playing = playbackService?.isPlaying() == true
        binding.btnNpPlayPause.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun togglePlayPause() {
        val nowPlaying = playbackService?.togglePlayPause() ?: false
        binding.btnNpPlayPause.setImageResource(if (nowPlaying) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun toggleFavorite() {
        val song = playbackService?.currentSong ?: return
        val nowFav = PrefsHelper.toggleFavorite(this, song.id)
        binding.btnNpFavorite.setImageResource(
            if (nowFav) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline
        )
    }

    private fun playNext() {
        val list = PlaybackSession.songs
        if (list.isEmpty()) return
        val next = if (shuffleOn && list.size > 1) {
            var r = list.indices.random()
            while (r == PlaybackSession.currentIndex) r = list.indices.random()
            r
        } else if (PlaybackSession.currentIndex + 1 < list.size) PlaybackSession.currentIndex + 1 else 0
        playIndex(next)
    }

    private fun playPrevious() {
        val list = PlaybackSession.songs
        if (list.isEmpty()) return
        val prev = if (shuffleOn && list.size > 1) {
            var r = list.indices.random()
            while (r == PlaybackSession.currentIndex) r = list.indices.random()
            r
        } else if (PlaybackSession.currentIndex - 1 >= 0) PlaybackSession.currentIndex - 1 else list.size - 1
        playIndex(prev)
    }

    private fun playIndex(index: Int) {
        val list = PlaybackSession.songs
        if (index !in list.indices) return
        PlaybackSession.currentIndex = index
        val song = list[index]
        playbackService?.playSong(song)
        PrefsHelper.addRecent(this, song.id)
        refreshUi()
    }

    private fun toggleStyle() {
        styleIndex = (styleIndex + 1) % 3
        applyStyle()
    }

    private fun toggleShuffle() {
        try {
            shuffleOn = !shuffleOn
            val theme = ThemeHelper.getSelected(this)
            binding.btnNpShuffle.setColorFilter(
                if (shuffleOn) theme.primary else ContextCompat_getColor(this, R.color.text_secondary)
            )
        } catch (e: Exception) {
            // rengi tetbiq ede bilmesek de shuffle veziyyeti deyisdi
        }
    }

    private fun toggleRepeat() {
        try {
            repeatOn = !repeatOn
            playbackService?.setLooping(repeatOn)
            val theme = ThemeHelper.getSelected(this)
            binding.btnNpRepeat.setColorFilter(
                if (repeatOn) theme.primary else ContextCompat_getColor(this, R.color.text_secondary)
            )
        } catch (e: Exception) {
            // rengi tetbiq ede bilmesek de repeat veziyyeti deyisdi
        }
    }

    private fun applyStyle() {
        try {
            when (styleIndex) {
                1 -> { // Gradient
                    val theme = ThemeHelper.getSelected(this)
                    val bg = GradientDrawable(
                        GradientDrawable.Orientation.TOP_BOTTOM,
                        intArrayOf(theme.dark, theme.primary, ContextCompat_getColor(this, R.color.bg_dark))
                    )
                    binding.rootNowPlaying.background = bg
                    binding.btnNpPlayPause.background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(theme.primary)
                    }
                    binding.npSeekBar.progressTintList = ColorStateList.valueOf(theme.light)
                    binding.npSeekBar.thumbTintList = ColorStateList.valueOf(theme.light)
                    setArtRounded(false)
                }
                2 -> { // Circle - dairevi albom sekli
                    binding.rootNowPlaying.setBackgroundColor(ContextCompat_getColor(this, R.color.bg_dark))
                    binding.btnNpPlayPause.setBackgroundResource(R.drawable.bg_circle_purple)
                    binding.npSeekBar.progressTintList = ColorStateList.valueOf(
                        ContextCompat_getColor(this, R.color.purple_700)
                    )
                    binding.npSeekBar.thumbTintList = ColorStateList.valueOf(
                        ContextCompat_getColor(this, R.color.purple_200)
                    )
                    setArtRounded(true)
                }
                else -> { // Normal
                    binding.rootNowPlaying.setBackgroundColor(ContextCompat_getColor(this, R.color.bg_dark))
                    binding.btnNpPlayPause.setBackgroundResource(R.drawable.bg_circle_purple)
                    binding.npSeekBar.progressTintList = ColorStateList.valueOf(
                        ContextCompat_getColor(this, R.color.purple_700)
                    )
                    binding.npSeekBar.thumbTintList = ColorStateList.valueOf(
                        ContextCompat_getColor(this, R.color.purple_200)
                    )
                    setArtRounded(false)
                }
            }
        } catch (e: Exception) {
            // Uslub tetbiq edile bilmese, ekran normal davam etsin
        }
    }

    private fun setArtRounded(rounded: Boolean) {
        try {
            if (rounded) {
                binding.ivNpArt.outlineProvider = object : android.view.ViewOutlineProvider() {
                    override fun getOutline(view: android.view.View, outline: android.graphics.Outline) {
                        outline.setOval(0, 0, view.width, view.height)
                    }
                }
            } else {
                binding.ivNpArt.outlineProvider = android.view.ViewOutlineProvider.BOUNDS
            }
            binding.ivNpArt.clipToOutline = rounded
        } catch (e: Exception) {
            // dairevi sekil tetbiq edile bilmese, adi kvadrat qalsin
        }
    }

    private fun ContextCompat_getColor(context: Context, colorRes: Int): Int {
        return androidx.core.content.ContextCompat.getColor(context, colorRes)
    }

    private fun formatTime(millis: Int): String {
        val minutes = TimeUnit.MILLISECONDS.toMinutes(millis.toLong())
        val seconds = TimeUnit.MILLISECONDS.toSeconds(millis.toLong()) % 60
        return String.format("%d:%02d", minutes, seconds)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(updateTask)
        if (isBound) {
            unbindService(connection)
            isBound = false
        }
    }
}
