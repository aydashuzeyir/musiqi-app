package com.example.offlinemusic

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        try {
            val theme = ThemeHelper.getSelected(this)
            val root = findViewById<android.widget.LinearLayout>(R.id.splashRoot)
            val bg = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(theme.dark, theme.primary, theme.dark)
            )
            root.background = bg

            findViewById<android.widget.TextView>(R.id.tvSplashWelcome).setTextColor(theme.light)
        } catch (e: Exception) {
            // tema tetbiq edile bilmese, defolt gradient qalsin
        }

        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }, 1300)
    }
}
