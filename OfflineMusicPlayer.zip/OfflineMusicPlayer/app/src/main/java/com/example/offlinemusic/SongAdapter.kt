package com.example.offlinemusic

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.offlinemusic.databinding.ItemSongBinding
import java.util.concurrent.TimeUnit

class SongAdapter(
    private val songs: List<Song>,
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<SongAdapter.SongViewHolder>() {

    var currentPlayingIndex: Int = -1
        set(value) {
            val old = field
            field = value
            if (old in songs.indices) notifyItemChanged(old)
            if (value in songs.indices) notifyItemChanged(value)
        }

    inner class SongViewHolder(val binding: ItemSongBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SongViewHolder {
        val binding = ItemSongBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return SongViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SongViewHolder, position: Int) {
        val song = songs[position]
        holder.binding.tvTitle.text = song.title
        holder.binding.tvArtist.text = song.artist
        holder.binding.tvDuration.text = formatDuration(song.duration)

        val isPlaying = position == currentPlayingIndex
        holder.binding.tvTitle.setTextColor(
            holder.itemView.context.getColor(
                if (isPlaying) R.color.purple_200 else R.color.white
            )
        )

        holder.itemView.setOnClickListener { onClick(position) }
    }

    override fun getItemCount(): Int = songs.size

    private fun formatDuration(millis: Long): String {
        val minutes = TimeUnit.MILLISECONDS.toMinutes(millis)
        val seconds = TimeUnit.MILLISECONDS.toSeconds(millis) % 60
        return String.format("%d:%02d", minutes, seconds)
    }
}
