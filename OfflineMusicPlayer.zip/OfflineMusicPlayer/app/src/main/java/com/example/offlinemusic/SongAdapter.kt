package com.example.offlinemusic

import android.content.ContentUris
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.offlinemusic.databinding.ItemSongBinding
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class SongAdapter(
    private val context: android.content.Context,
    private val songs: List<Song>,
    private val onClick: (Int) -> Unit,
    private val onFavoriteClick: (Int) -> Unit,
    private val onDeleteClick: (Int) -> Unit
) : RecyclerView.Adapter<SongAdapter.SongViewHolder>() {

    var currentPlayingIndex: Int = -1
        set(value) {
            val old = field
            field = value
            if (old in songs.indices) notifyItemChanged(old)
            if (value in songs.indices) notifyItemChanged(value)
        }

    private val mainHandler = Handler(Looper.getMainLooper())

    inner class SongViewHolder(val binding: ItemSongBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SongViewHolder {
        val binding = ItemSongBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return SongViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SongViewHolder, position: Int) {
        val song = songs[position]
        holder.binding.tvTitle.text = song.title
        holder.binding.tvArtist.text = song.artist
        holder.binding.tvDuration.text = formatDuration(song.duration)

        val isPlaying = position == currentPlayingIndex
        holder.binding.tvTitle.setTextColor(
            holder.itemView.context.getColor(
                if (isPlaying) R.color.purple_200 else R.color.white
            )
        )

        holder.binding.ivAlbumArt.setImageResource(R.drawable.ic_music_note)
        loadAlbumArt(song.albumId) { bitmap ->
            if (holder.bindingAdapterPosition == position && bitmap != null) {
                holder.binding.ivAlbumArt.setImageBitmap(bitmap)
            }
        }

        val isFav = PrefsHelper.isFavorite(holder.itemView.context, song.id)
        holder.binding.btnFavorite.setImageResource(
            if (isFav) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline
        )

        holder.itemView.setOnClickListener { onClick(position) }
        holder.binding.btnFavorite.setOnClickListener {
            onFavoriteClick(position)
            notifyItemChanged(position)
        }
        holder.binding.btnDelete.setOnClickListener {
            onDeleteClick(position)
        }
    }

    override fun getItemCount(): Int = songs.size

    private fun formatDuration(millis: Long): String {
        val minutes = TimeUnit.MILLISECONDS.toMinutes(millis)
        val seconds = TimeUnit.MILLISECONDS.toSeconds(millis) % 60
        return String.format("%d:%02d", minutes, seconds)
    }

    private fun loadAlbumArt(albumId: Long, callback: (Bitmap?) -> Unit) {
        executor.execute {
            val bitmap = try {
                val uri = ContentUris.withAppendedId(
                    Uri.parse("content://media/external/audio/albumart"), albumId
                )
                BitmapFactory.decodeStream(context.contentResolver.openInputStream(uri))
            } catch (e: Exception) {
                null
            }
            mainHandler.post { callback(bitmap) }
        }
    }

    companion object {
        private val executor: ExecutorService = Executors.newFixedThreadPool(3)
    }
}
